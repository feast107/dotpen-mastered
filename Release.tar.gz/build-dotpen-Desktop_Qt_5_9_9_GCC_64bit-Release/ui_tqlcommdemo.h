/********************************************************************************
** Form generated from reading UI file 'tqlcommdemo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TQLCOMMDEMO_H
#define UI_TQLCOMMDEMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TQLCommDemoClass
{
public:
    QAction *actionBlue;
    QAction *actionGreen;
    QAction *actionCyan;
    QAction *actionRed;
    QAction *actionMagenta;
    QAction *actionYellow;
    QAction *actionWhite;
    QAction *action1;
    QAction *action2;
    QAction *action3;
    QAction *action4;
    QAction *action5;
    QAction *action6;
    QAction *action1_2;
    QAction *action2_2;
    QAction *action3_2;
    QAction *action4_2;
    QAction *action5_2;
    QAction *action75;
    QAction *action100;
    QAction *action150;
    QAction *action200;
    QAction *action300;
    QAction *action400;
    QAction *actionStart_and_Stop;
    QAction *actionPause_adn_Continue;
    QAction *actionDelete_Off_Date;
    QAction *actionOff_Date_Number;
    QAction *actionattribute;
    QAction *actionpages;
    QAction *actionClearDraw;
    QAction *actionClearlog;
    QAction *actionClearAll;
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QListWidget *listWidget;
    QGroupBox *groupBox_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QWidget *widget;
    QPushButton *submitbutton;
    QMenuBar *menuBar;
    QMenu *menuPen_Attritude;
    QMenu *menuPen_Color;
    QMenu *menu_width;
    QMenu *menu_playback;
    QMenu *menu_zoom;
    QMenu *menu_OffDate;
    QMenu *menuChange_Page;
    QMenu *menuClear;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *TQLCommDemoClass)
    {
        if (TQLCommDemoClass->objectName().isEmpty())
            TQLCommDemoClass->setObjectName(QStringLiteral("TQLCommDemoClass"));
        TQLCommDemoClass->resize(1073, 926);
        actionBlue = new QAction(TQLCommDemoClass);
        actionBlue->setObjectName(QStringLiteral("actionBlue"));
        actionGreen = new QAction(TQLCommDemoClass);
        actionGreen->setObjectName(QStringLiteral("actionGreen"));
        actionCyan = new QAction(TQLCommDemoClass);
        actionCyan->setObjectName(QStringLiteral("actionCyan"));
        actionRed = new QAction(TQLCommDemoClass);
        actionRed->setObjectName(QStringLiteral("actionRed"));
        actionMagenta = new QAction(TQLCommDemoClass);
        actionMagenta->setObjectName(QStringLiteral("actionMagenta"));
        actionYellow = new QAction(TQLCommDemoClass);
        actionYellow->setObjectName(QStringLiteral("actionYellow"));
        actionWhite = new QAction(TQLCommDemoClass);
        actionWhite->setObjectName(QStringLiteral("actionWhite"));
        action1 = new QAction(TQLCommDemoClass);
        action1->setObjectName(QStringLiteral("action1"));
        action2 = new QAction(TQLCommDemoClass);
        action2->setObjectName(QStringLiteral("action2"));
        action3 = new QAction(TQLCommDemoClass);
        action3->setObjectName(QStringLiteral("action3"));
        action4 = new QAction(TQLCommDemoClass);
        action4->setObjectName(QStringLiteral("action4"));
        action5 = new QAction(TQLCommDemoClass);
        action5->setObjectName(QStringLiteral("action5"));
        action6 = new QAction(TQLCommDemoClass);
        action6->setObjectName(QStringLiteral("action6"));
        action1_2 = new QAction(TQLCommDemoClass);
        action1_2->setObjectName(QStringLiteral("action1_2"));
        action2_2 = new QAction(TQLCommDemoClass);
        action2_2->setObjectName(QStringLiteral("action2_2"));
        action3_2 = new QAction(TQLCommDemoClass);
        action3_2->setObjectName(QStringLiteral("action3_2"));
        action4_2 = new QAction(TQLCommDemoClass);
        action4_2->setObjectName(QStringLiteral("action4_2"));
        action5_2 = new QAction(TQLCommDemoClass);
        action5_2->setObjectName(QStringLiteral("action5_2"));
        action75 = new QAction(TQLCommDemoClass);
        action75->setObjectName(QStringLiteral("action75"));
        action100 = new QAction(TQLCommDemoClass);
        action100->setObjectName(QStringLiteral("action100"));
        action150 = new QAction(TQLCommDemoClass);
        action150->setObjectName(QStringLiteral("action150"));
        action200 = new QAction(TQLCommDemoClass);
        action200->setObjectName(QStringLiteral("action200"));
        action300 = new QAction(TQLCommDemoClass);
        action300->setObjectName(QStringLiteral("action300"));
        action400 = new QAction(TQLCommDemoClass);
        action400->setObjectName(QStringLiteral("action400"));
        actionStart_and_Stop = new QAction(TQLCommDemoClass);
        actionStart_and_Stop->setObjectName(QStringLiteral("actionStart_and_Stop"));
        actionPause_adn_Continue = new QAction(TQLCommDemoClass);
        actionPause_adn_Continue->setObjectName(QStringLiteral("actionPause_adn_Continue"));
        actionDelete_Off_Date = new QAction(TQLCommDemoClass);
        actionDelete_Off_Date->setObjectName(QStringLiteral("actionDelete_Off_Date"));
        actionOff_Date_Number = new QAction(TQLCommDemoClass);
        actionOff_Date_Number->setObjectName(QStringLiteral("actionOff_Date_Number"));
        actionattribute = new QAction(TQLCommDemoClass);
        actionattribute->setObjectName(QStringLiteral("actionattribute"));
        actionpages = new QAction(TQLCommDemoClass);
        actionpages->setObjectName(QStringLiteral("actionpages"));
        actionClearDraw = new QAction(TQLCommDemoClass);
        actionClearDraw->setObjectName(QStringLiteral("actionClearDraw"));
        actionClearlog = new QAction(TQLCommDemoClass);
        actionClearlog->setObjectName(QStringLiteral("actionClearlog"));
        actionClearAll = new QAction(TQLCommDemoClass);
        actionClearAll->setObjectName(QStringLiteral("actionClearAll"));
        centralWidget = new QWidget(TQLCommDemoClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(0, 0, 331, 451));
        listWidget = new QListWidget(groupBox);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(10, 20, 311, 421));
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(330, 0, 731, 861));
        scrollArea = new QScrollArea(groupBox_2);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(10, 20, 711, 831));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 709, 829));
        scrollAreaWidgetContents->setMinimumSize(QSize(0, 0));
        widget = new QWidget(scrollAreaWidgetContents);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(-1, -1, 711, 831));
        scrollArea->setWidget(scrollAreaWidgetContents);
        submitbutton = new QPushButton(centralWidget);
        submitbutton->setObjectName(QStringLiteral("submitbutton"));
        submitbutton->setGeometry(QRect(120, 510, 91, 81));
        TQLCommDemoClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(TQLCommDemoClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1073, 23));
        menuPen_Attritude = new QMenu(menuBar);
        menuPen_Attritude->setObjectName(QStringLiteral("menuPen_Attritude"));
        menuPen_Color = new QMenu(menuBar);
        menuPen_Color->setObjectName(QStringLiteral("menuPen_Color"));
        menu_width = new QMenu(menuBar);
        menu_width->setObjectName(QStringLiteral("menu_width"));
        menu_playback = new QMenu(menuBar);
        menu_playback->setObjectName(QStringLiteral("menu_playback"));
        menu_zoom = new QMenu(menuBar);
        menu_zoom->setObjectName(QStringLiteral("menu_zoom"));
        menu_OffDate = new QMenu(menuBar);
        menu_OffDate->setObjectName(QStringLiteral("menu_OffDate"));
        menuChange_Page = new QMenu(menuBar);
        menuChange_Page->setObjectName(QStringLiteral("menuChange_Page"));
        menuClear = new QMenu(menuBar);
        menuClear->setObjectName(QStringLiteral("menuClear"));
        TQLCommDemoClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(TQLCommDemoClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        TQLCommDemoClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(TQLCommDemoClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        TQLCommDemoClass->setStatusBar(statusBar);

        menuBar->addAction(menuPen_Attritude->menuAction());
        menuBar->addAction(menuPen_Color->menuAction());
        menuBar->addAction(menu_width->menuAction());
        menuBar->addAction(menu_playback->menuAction());
        menuBar->addAction(menu_zoom->menuAction());
        menuBar->addAction(menu_OffDate->menuAction());
        menuBar->addAction(menuChange_Page->menuAction());
        menuBar->addAction(menuClear->menuAction());
        menuPen_Attritude->addAction(actionattribute);
        menuPen_Color->addAction(actionBlue);
        menuPen_Color->addAction(actionGreen);
        menuPen_Color->addAction(actionCyan);
        menuPen_Color->addAction(actionRed);
        menuPen_Color->addAction(actionMagenta);
        menuPen_Color->addAction(actionYellow);
        menuPen_Color->addAction(actionWhite);
        menu_width->addAction(action1);
        menu_width->addAction(action2);
        menu_width->addAction(action3);
        menu_width->addAction(action4);
        menu_width->addAction(action5);
        menu_width->addAction(action6);
        menu_playback->addAction(action1_2);
        menu_playback->addAction(action2_2);
        menu_playback->addAction(action3_2);
        menu_playback->addAction(action4_2);
        menu_playback->addAction(action5_2);
        menu_zoom->addAction(action75);
        menu_zoom->addAction(action100);
        menu_zoom->addAction(action150);
        menu_zoom->addAction(action200);
        menu_zoom->addAction(action300);
        menu_zoom->addAction(action400);
        menu_OffDate->addAction(actionOff_Date_Number);
        menu_OffDate->addAction(actionStart_and_Stop);
        menu_OffDate->addAction(actionPause_adn_Continue);
        menu_OffDate->addAction(actionDelete_Off_Date);
        menuChange_Page->addAction(actionpages);
        menuClear->addAction(actionClearDraw);
        menuClear->addAction(actionClearlog);
        menuClear->addAction(actionClearAll);

        retranslateUi(TQLCommDemoClass);

        QMetaObject::connectSlotsByName(TQLCommDemoClass);
    } // setupUi

    void retranslateUi(QMainWindow *TQLCommDemoClass)
    {
        TQLCommDemoClass->setWindowTitle(QApplication::translate("TQLCommDemoClass", "\346\231\272\350\203\275\347\255\276\346\211\271", Q_NULLPTR));
        actionBlue->setText(QApplication::translate("TQLCommDemoClass", "\350\223\235\350\211\262", Q_NULLPTR));
        actionGreen->setText(QApplication::translate("TQLCommDemoClass", "\347\273\277\350\211\262", Q_NULLPTR));
        actionCyan->setText(QApplication::translate("TQLCommDemoClass", "\351\235\222\350\211\262", Q_NULLPTR));
        actionRed->setText(QApplication::translate("TQLCommDemoClass", "\347\272\242\350\211\262", Q_NULLPTR));
        actionMagenta->setText(QApplication::translate("TQLCommDemoClass", "\345\223\201\347\272\242", Q_NULLPTR));
        actionYellow->setText(QApplication::translate("TQLCommDemoClass", "\351\273\204\350\211\262", Q_NULLPTR));
        actionWhite->setText(QApplication::translate("TQLCommDemoClass", "\347\231\275(\351\273\221)\350\211\262", Q_NULLPTR));
        action1->setText(QApplication::translate("TQLCommDemoClass", "1", Q_NULLPTR));
        action2->setText(QApplication::translate("TQLCommDemoClass", "2", Q_NULLPTR));
        action3->setText(QApplication::translate("TQLCommDemoClass", "3", Q_NULLPTR));
        action4->setText(QApplication::translate("TQLCommDemoClass", "4", Q_NULLPTR));
        action5->setText(QApplication::translate("TQLCommDemoClass", "5", Q_NULLPTR));
        action6->setText(QApplication::translate("TQLCommDemoClass", "6", Q_NULLPTR));
        action1_2->setText(QApplication::translate("TQLCommDemoClass", "1", Q_NULLPTR));
        action2_2->setText(QApplication::translate("TQLCommDemoClass", "2", Q_NULLPTR));
        action3_2->setText(QApplication::translate("TQLCommDemoClass", "3", Q_NULLPTR));
        action4_2->setText(QApplication::translate("TQLCommDemoClass", "4", Q_NULLPTR));
        action5_2->setText(QApplication::translate("TQLCommDemoClass", "5", Q_NULLPTR));
        action75->setText(QApplication::translate("TQLCommDemoClass", "75%", Q_NULLPTR));
        action100->setText(QApplication::translate("TQLCommDemoClass", "100%", Q_NULLPTR));
        action150->setText(QApplication::translate("TQLCommDemoClass", "150%", Q_NULLPTR));
        action200->setText(QApplication::translate("TQLCommDemoClass", "200%", Q_NULLPTR));
        action300->setText(QApplication::translate("TQLCommDemoClass", "300%", Q_NULLPTR));
        action400->setText(QApplication::translate("TQLCommDemoClass", "400%", Q_NULLPTR));
        actionStart_and_Stop->setText(QApplication::translate("TQLCommDemoClass", "\345\274\200\345\247\213\344\270\213\350\275\275", Q_NULLPTR));
        actionPause_adn_Continue->setText(QApplication::translate("TQLCommDemoClass", "\346\232\202\345\201\234\344\270\213\350\275\275", Q_NULLPTR));
        actionDelete_Off_Date->setText(QApplication::translate("TQLCommDemoClass", "\345\210\240\351\231\244\347\246\273\347\272\277", Q_NULLPTR));
        actionOff_Date_Number->setText(QApplication::translate("TQLCommDemoClass", "\347\246\273\347\272\277\346\225\260\346\215\256\351\207\217", Q_NULLPTR));
        actionattribute->setText(QApplication::translate("TQLCommDemoClass", "\345\261\236\346\200\247", Q_NULLPTR));
        actionpages->setText(QApplication::translate("TQLCommDemoClass", "\345\210\207\351\241\265", Q_NULLPTR));
        actionClearDraw->setText(QApplication::translate("TQLCommDemoClass", "\347\273\230\347\224\273", Q_NULLPTR));
        actionClearlog->setText(QApplication::translate("TQLCommDemoClass", "\346\227\245\345\277\227", Q_NULLPTR));
        actionClearAll->setText(QApplication::translate("TQLCommDemoClass", "\346\211\200\346\234\211", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("TQLCommDemoClass", "\346\227\245\345\277\227", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("TQLCommDemoClass", "\347\273\230\347\224\273", Q_NULLPTR));
        submitbutton->setText(QApplication::translate("TQLCommDemoClass", "\346\217\220\344\272\244", Q_NULLPTR));
        menuPen_Attritude->setTitle(QApplication::translate("TQLCommDemoClass", "\346\231\272\350\203\275\347\254\224", Q_NULLPTR));
        menuPen_Color->setTitle(QApplication::translate("TQLCommDemoClass", "LED\351\242\234\350\211\262(\347\254\224\350\277\271\351\242\234\350\211\262)", Q_NULLPTR));
        menu_width->setTitle(QApplication::translate("TQLCommDemoClass", "\347\254\224\350\277\271\345\256\275\345\272\246", Q_NULLPTR));
        menu_playback->setTitle(QApplication::translate("TQLCommDemoClass", "\347\254\224\350\277\271\345\233\236\346\224\276", Q_NULLPTR));
        menu_zoom->setTitle(QApplication::translate("TQLCommDemoClass", "\347\274\251\346\224\276", Q_NULLPTR));
        menu_OffDate->setTitle(QApplication::translate("TQLCommDemoClass", "\347\246\273\347\272\277\346\225\260\346\215\256\346\223\215\344\275\234", Q_NULLPTR));
        menuChange_Page->setTitle(QApplication::translate("TQLCommDemoClass", "\351\241\265\351\235\242\346\223\215\344\275\234", Q_NULLPTR));
        menuClear->setTitle(QApplication::translate("TQLCommDemoClass", "\346\270\205\351\231\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TQLCommDemoClass: public Ui_TQLCommDemoClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TQLCOMMDEMO_H
