/********************************************************************************
** Form generated from reading UI file 'Attritude.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATTRITUDE_H
#define UI_ATTRITUDE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Attritude
{
public:
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_3;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_5;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_6;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_7;
    QLineEdit *lineEdit_7;
    QPushButton *pushButton_8;
    QLineEdit *lineEdit_8;
    QPushButton *pushButton_9;
    QLineEdit *lineEdit_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QComboBox *comboBox_1;
    QPushButton *pushButton_15;
    QComboBox *comboBox_2;
    QPushButton *pushButton_16;
    QComboBox *comboBox_3;
    QPushButton *pushButton_17;
    QComboBox *comboBox_4;

    void setupUi(QDialog *Attritude)
    {
        if (Attritude->objectName().isEmpty())
            Attritude->setObjectName(QStringLiteral("Attritude"));
        Attritude->resize(600, 542);
        pushButton = new QPushButton(Attritude);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 40, 75, 23));
        lineEdit = new QLineEdit(Attritude);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(140, 40, 113, 20));
        lineEdit->setReadOnly(true);
        pushButton_2 = new QPushButton(Attritude);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(320, 40, 71, 23));
        lineEdit_2 = new QLineEdit(Attritude);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(410, 40, 113, 20));
        lineEdit_2->setReadOnly(true);
        pushButton_3 = new QPushButton(Attritude);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(50, 90, 75, 23));
        lineEdit_3 = new QLineEdit(Attritude);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(140, 90, 113, 20));
        lineEdit_3->setReadOnly(true);
        pushButton_4 = new QPushButton(Attritude);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(320, 90, 75, 23));
        lineEdit_4 = new QLineEdit(Attritude);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(410, 90, 113, 20));
        lineEdit_4->setReadOnly(true);
        pushButton_5 = new QPushButton(Attritude);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(50, 140, 75, 23));
        lineEdit_5 = new QLineEdit(Attritude);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(140, 140, 113, 20));
        lineEdit_5->setReadOnly(true);
        pushButton_6 = new QPushButton(Attritude);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(320, 140, 75, 23));
        lineEdit_6 = new QLineEdit(Attritude);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(410, 140, 113, 20));
        lineEdit_6->setReadOnly(true);
        pushButton_7 = new QPushButton(Attritude);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(104, 320, 101, 23));
        lineEdit_7 = new QLineEdit(Attritude);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(220, 320, 141, 20));
        pushButton_8 = new QPushButton(Attritude);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(104, 370, 101, 23));
        lineEdit_8 = new QLineEdit(Attritude);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(220, 370, 141, 20));
        pushButton_9 = new QPushButton(Attritude);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(104, 420, 101, 23));
        lineEdit_9 = new QLineEdit(Attritude);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(220, 420, 141, 20));
        pushButton_10 = new QPushButton(Attritude);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(390, 320, 101, 23));
        pushButton_11 = new QPushButton(Attritude);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(390, 370, 101, 23));
        pushButton_12 = new QPushButton(Attritude);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(390, 420, 101, 23));
        pushButton_13 = new QPushButton(Attritude);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(210, 480, 141, 41));
        pushButton_14 = new QPushButton(Attritude);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(50, 200, 75, 23));
        comboBox_1 = new QComboBox(Attritude);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setGeometry(QRect(140, 200, 111, 22));
        pushButton_15 = new QPushButton(Attritude);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(320, 200, 75, 23));
        comboBox_2 = new QComboBox(Attritude);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(410, 200, 111, 22));
        pushButton_16 = new QPushButton(Attritude);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(50, 250, 75, 23));
        comboBox_3 = new QComboBox(Attritude);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(140, 250, 111, 22));
        pushButton_17 = new QPushButton(Attritude);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(320, 250, 75, 23));
        comboBox_4 = new QComboBox(Attritude);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(410, 250, 111, 22));

        retranslateUi(Attritude);

        comboBox_3->setCurrentIndex(6);


        QMetaObject::connectSlotsByName(Attritude);
    } // setupUi

    void retranslateUi(QDialog *Attritude)
    {
        Attritude->setWindowTitle(QApplication::translate("Attritude", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Attritude", "\350\223\235\347\211\231\345\234\260\345\235\200", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Attritude", "\350\223\235\347\211\231\347\211\210\346\234\254\345\217\267", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Attritude", "\345\211\251\344\275\231\347\224\265\351\207\217", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Attritude", "MCU\347\211\210\346\234\254\345\217\267", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Attritude", "\344\275\277\347\224\250\345\206\205\345\255\230", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("Attritude", "MCU\345\272\217\345\210\227\345\217\267", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("Attritude", "\350\216\267\345\217\226RTC", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("Attritude", "\350\207\252\345\212\250\344\274\221\347\234\240\346\227\266\351\227\264", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("Attritude", "\346\231\272\350\203\275\347\254\224\347\254\224\345\220\215", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("Attritude", "\345\220\214\346\255\245RTC", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("Attritude", "\350\256\276\347\275\256\350\207\252\345\212\250\344\274\221\347\234\240\346\227\266\351\227\264", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("Attritude", "\350\256\276\347\275\256\346\231\272\350\203\275\347\254\224\347\254\224\345\220\215", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("Attritude", "\350\216\267\345\217\226\346\231\272\350\203\275\347\254\224\345\261\236\346\200\247", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("Attritude", "\350\234\202\351\270\243\345\231\250\346\230\257\345\220\246\345\223\215", Q_NULLPTR));
        comboBox_1->clear();
        comboBox_1->insertItems(0, QStringList()
         << QApplication::translate("Attritude", "\345\220\246", Q_NULLPTR)
         << QApplication::translate("Attritude", "\346\230\257", Q_NULLPTR)
        );
        pushButton_15->setText(QApplication::translate("Attritude", "\345\216\213\345\212\233\345\224\244\351\206\222", Q_NULLPTR));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("Attritude", "\345\220\246", Q_NULLPTR)
         << QApplication::translate("Attritude", "\346\230\257", Q_NULLPTR)
        );
        pushButton_16->setText(QApplication::translate("Attritude", "LED\351\242\234\350\211\262", Q_NULLPTR));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("Attritude", "\350\223\235\350\211\262", Q_NULLPTR)
         << QApplication::translate("Attritude", "\347\273\277\350\211\262", Q_NULLPTR)
         << QApplication::translate("Attritude", "\351\235\222\350\211\262", Q_NULLPTR)
         << QApplication::translate("Attritude", "\347\272\242\350\211\262", Q_NULLPTR)
         << QApplication::translate("Attritude", "\345\223\201\347\272\242", Q_NULLPTR)
         << QApplication::translate("Attritude", "\351\273\204\350\211\262", Q_NULLPTR)
         << QApplication::translate("Attritude", "\347\231\275\350\211\262", Q_NULLPTR)
        );
        pushButton_17->setText(QApplication::translate("Attritude", "\345\216\213\345\212\233\346\225\217\346\204\237\345\272\246", Q_NULLPTR));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("Attritude", "0", Q_NULLPTR)
         << QApplication::translate("Attritude", "1", Q_NULLPTR)
         << QApplication::translate("Attritude", "2", Q_NULLPTR)
         << QApplication::translate("Attritude", "3", Q_NULLPTR)
         << QApplication::translate("Attritude", "4", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class Attritude: public Ui_Attritude {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATTRITUDE_H
