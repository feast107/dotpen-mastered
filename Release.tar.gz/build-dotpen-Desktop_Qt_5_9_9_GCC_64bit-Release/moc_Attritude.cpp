/****************************************************************************
** Meta object code from reading C++ file 'Attritude.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dotpen/Attritude.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Attritude.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Attritude_t {
    QByteArrayData data[24];
    char stringdata0[380];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Attritude_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Attritude_t qt_meta_stringdata_Attritude = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Attritude"
QT_MOC_LITERAL(1, 10, 12), // "GetAttritude"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 13), // "button1_Click"
QT_MOC_LITERAL(4, 38, 13), // "button4_Click"
QT_MOC_LITERAL(5, 52, 13), // "button2_Click"
QT_MOC_LITERAL(6, 66, 13), // "button5_Click"
QT_MOC_LITERAL(7, 80, 13), // "button3_Click"
QT_MOC_LITERAL(8, 94, 13), // "button6_Click"
QT_MOC_LITERAL(9, 108, 13), // "button8_Click"
QT_MOC_LITERAL(10, 122, 13), // "button7_Click"
QT_MOC_LITERAL(11, 136, 13), // "button9_Click"
QT_MOC_LITERAL(12, 150, 14), // "button10_Click"
QT_MOC_LITERAL(13, 165, 14), // "button13_Click"
QT_MOC_LITERAL(14, 180, 14), // "button15_Click"
QT_MOC_LITERAL(15, 195, 14), // "button17_Click"
QT_MOC_LITERAL(16, 210, 14), // "button11_Click"
QT_MOC_LITERAL(17, 225, 14), // "button12_Click"
QT_MOC_LITERAL(18, 240, 14), // "button14_Click"
QT_MOC_LITERAL(19, 255, 28), // "comboBox_currentIndexChanged"
QT_MOC_LITERAL(20, 284, 5), // "Index"
QT_MOC_LITERAL(21, 290, 29), // "comboBox_2currentIndexChanged"
QT_MOC_LITERAL(22, 320, 29), // "comboBox_3currentIndexChanged"
QT_MOC_LITERAL(23, 350, 29) // "comboBox_4currentIndexChanged"

    },
    "Attritude\0GetAttritude\0\0button1_Click\0"
    "button4_Click\0button2_Click\0button5_Click\0"
    "button3_Click\0button6_Click\0button8_Click\0"
    "button7_Click\0button9_Click\0button10_Click\0"
    "button13_Click\0button15_Click\0"
    "button17_Click\0button11_Click\0"
    "button12_Click\0button14_Click\0"
    "comboBox_currentIndexChanged\0Index\0"
    "comboBox_2currentIndexChanged\0"
    "comboBox_3currentIndexChanged\0"
    "comboBox_4currentIndexChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Attritude[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x08 /* Private */,
       3,    0,  120,    2, 0x08 /* Private */,
       4,    0,  121,    2, 0x08 /* Private */,
       5,    0,  122,    2, 0x08 /* Private */,
       6,    0,  123,    2, 0x08 /* Private */,
       7,    0,  124,    2, 0x08 /* Private */,
       8,    0,  125,    2, 0x08 /* Private */,
       9,    0,  126,    2, 0x08 /* Private */,
      10,    0,  127,    2, 0x08 /* Private */,
      11,    0,  128,    2, 0x08 /* Private */,
      12,    0,  129,    2, 0x08 /* Private */,
      13,    0,  130,    2, 0x08 /* Private */,
      14,    0,  131,    2, 0x08 /* Private */,
      15,    0,  132,    2, 0x08 /* Private */,
      16,    0,  133,    2, 0x08 /* Private */,
      17,    0,  134,    2, 0x08 /* Private */,
      18,    0,  135,    2, 0x08 /* Private */,
      19,    1,  136,    2, 0x08 /* Private */,
      21,    1,  139,    2, 0x08 /* Private */,
      22,    1,  142,    2, 0x08 /* Private */,
      23,    1,  145,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,

       0        // eod
};

void Attritude::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Attritude *_t = static_cast<Attritude *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->GetAttritude(); break;
        case 1: _t->button1_Click(); break;
        case 2: _t->button4_Click(); break;
        case 3: _t->button2_Click(); break;
        case 4: _t->button5_Click(); break;
        case 5: _t->button3_Click(); break;
        case 6: _t->button6_Click(); break;
        case 7: _t->button8_Click(); break;
        case 8: _t->button7_Click(); break;
        case 9: _t->button9_Click(); break;
        case 10: _t->button10_Click(); break;
        case 11: _t->button13_Click(); break;
        case 12: _t->button15_Click(); break;
        case 13: _t->button17_Click(); break;
        case 14: _t->button11_Click(); break;
        case 15: _t->button12_Click(); break;
        case 16: _t->button14_Click(); break;
        case 17: _t->comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->comboBox_2currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->comboBox_3currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->comboBox_4currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject Attritude::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Attritude.data,
      qt_meta_data_Attritude,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Attritude::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Attritude::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Attritude.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int Attritude::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
