/********************************************************************************
** Form generated from reading UI file 'SetPageLoad.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETPAGELOAD_H
#define UI_SETPAGELOAD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_SetPageLoad
{
public:
    QComboBox *comboBox;
    QLabel *label;

    void setupUi(QDialog *SetPageLoad)
    {
        if (SetPageLoad->objectName().isEmpty())
            SetPageLoad->setObjectName(QStringLiteral("SetPageLoad"));
        SetPageLoad->resize(296, 53);
        comboBox = new QComboBox(SetPageLoad);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(120, 20, 111, 22));
        label = new QLabel(SetPageLoad);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 20, 54, 12));

        retranslateUi(SetPageLoad);

        QMetaObject::connectSlotsByName(SetPageLoad);
    } // setupUi

    void retranslateUi(QDialog *SetPageLoad)
    {
        SetPageLoad->setWindowTitle(QApplication::translate("SetPageLoad", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("SetPageLoad", "\351\241\265\351\235\242\351\200\211\346\213\251\357\274\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SetPageLoad: public Ui_SetPageLoad {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETPAGELOAD_H
